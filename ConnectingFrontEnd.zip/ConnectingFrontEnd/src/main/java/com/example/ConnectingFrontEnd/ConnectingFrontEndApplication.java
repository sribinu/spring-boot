package com.example.ConnectingFrontEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectingFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectingFrontEndApplication.class, args);
	}

}
